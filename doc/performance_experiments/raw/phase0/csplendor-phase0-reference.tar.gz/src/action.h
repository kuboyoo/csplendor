#ifndef CSPLENDOR_ACTION_H
#define CSPLENDOR_ACTION_H

#include "types.h"
#include <algorithm>
#include <array> // Added for std::array
#include <sstream>
#include <string>

struct Action {
  ActionType type = ACTION_TYPE_COUNT; // Initialized to an invalid type

  // For TAKE_DIFFERENT, TAKE_SAME
  std::array<uint8_t, 5> take = {0}; // [Diamond, Sapphire, Emerald, Ruby, Onyx]

  // For RESERVE_VISIBLE, RESERVE_DECK, PURCHASE
  int8_t card_id = -1;        // Card ID
  int8_t deck_level = -1;     // 0, 1, 2
  bool from_reserved = false; // Purchasing from reserved cards

  // For PURCHASE: How gold is used for each color
  std::array<uint8_t, 5> gold_as = {0};

  // For token return (when exceeding 10 gems)
  std::array<uint8_t, 6> return_gems = {0}; // Five colors above, then Gold

  // For noble choice (if multiple are eligible)
  int8_t noble_choice = -1; // ID of the noble chosen

  bool is_token_noop() const {
    if (type != TAKE_DIFFERENT && type != TAKE_SAME)
      return false;
    for (int color = 0; color < 5; ++color) {
      if (take[color] != return_gems[color])
        return false;
    }
    return return_gems[GOLD] == 0;
  }

  uint64_t pack() const {
    uint64_t code = static_cast<uint64_t>(type) & 0x7ULL;

    switch (type) {
    case TAKE_DIFFERENT:
    case TAKE_SAME: {
      int shift = 3;
      for (int i = 0; i < 5; ++i, shift += 2)
        code |= (static_cast<uint64_t>(take[i]) & 0x3ULL) << shift;
      for (int i = 0; i < 6; ++i, shift += 4)
        code |= (static_cast<uint64_t>(return_gems[i]) & 0xFULL) << shift;
      break;
    }
    case RESERVE_VISIBLE: {
      code |= (static_cast<uint64_t>(card_id + 1) & 0x7FULL) << 3;
      int shift = 10;
      for (int i = 0; i < 6; ++i, shift += 4)
        code |= (static_cast<uint64_t>(return_gems[i]) & 0xFULL) << shift;
      break;
    }
    case RESERVE_DECK: {
      code |= (static_cast<uint64_t>(deck_level + 1) & 0x3ULL) << 3;
      int shift = 5;
      for (int i = 0; i < 6; ++i, shift += 4)
        code |= (static_cast<uint64_t>(return_gems[i]) & 0xFULL) << shift;
      break;
    }
    case PURCHASE: {
      code |= (static_cast<uint64_t>(card_id + 1) & 0x7FULL) << 3;
      code |= (static_cast<uint64_t>(from_reserved ? 1 : 0) & 0x1ULL) << 10;
      int shift = 11;
      for (int i = 0; i < 5; ++i, shift += 3)
        code |= (static_cast<uint64_t>(gold_as[i]) & 0x7ULL) << shift;
      break;
    }
    case VISIT_NOBLE:
      code |= (static_cast<uint64_t>(noble_choice + 1) & 0x1FULL) << 3;
      break;
    case PASS:
      break;
    default:
      break;
    }

    return code;
  }

  static Action unpack(uint64_t code) {
    Action action;
    action.type = static_cast<ActionType>(code & 0x7ULL);

    switch (action.type) {
    case TAKE_DIFFERENT:
    case TAKE_SAME: {
      int shift = 3;
      for (int i = 0; i < 5; ++i, shift += 2)
        action.take[i] = static_cast<uint8_t>((code >> shift) & 0x3ULL);
      for (int i = 0; i < 6; ++i, shift += 4)
        action.return_gems[i] =
            static_cast<uint8_t>((code >> shift) & 0xFULL);
      break;
    }
    case RESERVE_VISIBLE: {
      int card = static_cast<int>((code >> 3) & 0x7FULL);
      action.card_id = static_cast<int8_t>(card - 1);
      int shift = 10;
      for (int i = 0; i < 6; ++i, shift += 4)
        action.return_gems[i] =
            static_cast<uint8_t>((code >> shift) & 0xFULL);
      break;
    }
    case RESERVE_DECK: {
      int deck = static_cast<int>((code >> 3) & 0x3ULL);
      action.deck_level = static_cast<int8_t>(deck - 1);
      int shift = 5;
      for (int i = 0; i < 6; ++i, shift += 4)
        action.return_gems[i] =
            static_cast<uint8_t>((code >> shift) & 0xFULL);
      break;
    }
    case PURCHASE: {
      int card = static_cast<int>((code >> 3) & 0x7FULL);
      action.card_id = static_cast<int8_t>(card - 1);
      action.from_reserved = ((code >> 10) & 0x1ULL) != 0;
      int shift = 11;
      for (int i = 0; i < 5; ++i, shift += 3)
        action.gold_as[i] = static_cast<uint8_t>((code >> shift) & 0x7ULL);
      break;
    }
    case VISIT_NOBLE:
      action.noble_choice =
          static_cast<int8_t>(static_cast<int>((code >> 3) & 0x1FULL) - 1);
      break;
    case PASS:
      break;
    default:
      action.type = ACTION_TYPE_COUNT;
      break;
    }

    return action;
  }

  bool operator==(const Action &other) const {
    if (type != other.type)
      return false;
    for (int i = 0; i < 5; ++i)
      if (take[i] != other.take[i])
        return false;
    if (card_id != other.card_id)
      return false;
    if (deck_level != other.deck_level)
      return false;
    if (from_reserved != other.from_reserved)
      return false;
    for (int i = 0; i < 5; ++i)
      if (gold_as[i] != other.gold_as[i])
        return false;
    for (int i = 0; i < 6; ++i)
      if (return_gems[i] != other.return_gems[i])
        return false;
    if (noble_choice != other.noble_choice)
      return false;
    return true;
  }

  std::string to_string() const {
    std::stringstream ss;
    switch (type) {
    case TAKE_DIFFERENT:
      ss << "TAKE_DIFFERENT: ";
      for (int i = 0; i < 5; ++i)
        if (take[i])
          ss << (int)take[i] << "x" << i << " ";
      break;
    case TAKE_SAME:
      ss << "TAKE_SAME: ";
      for (int i = 0; i < 5; ++i)
        if (take[i])
          ss << (int)take[i] << "x" << i << " ";
      break;
    case RESERVE_VISIBLE:
      ss << "RESERVE_VISIBLE: C" << (int)card_id;
      break;
    case RESERVE_DECK:
      ss << "RESERVE_DECK: L" << (int)deck_level + 1;
      break;
    case PURCHASE:
      ss << "PURCHASE: C" << (int)card_id << (from_reserved ? " (R)" : "");
      break;
    case VISIT_NOBLE:
      ss << "VISIT_NOBLE: N" << (int)noble_choice;
      break;
    case PASS:
      ss << "PASS";
      break;
    default:
      ss << "INVALID";
      break;
    }

    bool has_return = false;
    for (int i = 0; i < 6; ++i)
      if (return_gems[i])
        has_return = true;
    if (has_return) {
      ss << " RETURN: ";
      for (int i = 0; i < 6; ++i)
        if (return_gems[i])
          ss << (int)return_gems[i] << "x" << i << " ";
    }

    if (noble_choice != -1 && type != VISIT_NOBLE) {
      ss << " NOBLE: N" << (int)noble_choice;
    }

    return ss.str();
  }
};

// Fixed-size move list for MoveGenerator - avoids heap allocations
static constexpr size_t MAX_MOVES = 2048;

struct MoveList {
  std::array<Action, MAX_MOVES> data;
  uint16_t count = 0;

  void clear() { count = 0; }
  bool empty() const { return count == 0; }
  size_t size() const { return count; }

  void push_back(const Action &a) {
    if (count < MAX_MOVES)
      data[count++] = a;
  }

  Action &operator[](size_t i) { return data[i]; }
  const Action &operator[](size_t i) const { return data[i]; }

  Action *begin() { return data.data(); }
  Action *end() { return data.data() + count; }
  const Action *begin() const { return data.data(); }
  const Action *end() const { return data.data() + count; }
};

#endif // CSPLENDOR_ACTION_H
