# Phase 1A exact Zobrist hash mutation-path audit

対象: `/tmp/csplendor-codex56-phase0` の未コミット Phase 0 ソース

## 正本要件

`doc/csplendor_codex56_engine_optimization_request.md` 6.1–6.6 を確認した。

- editor/raw path は従来どおり cache invalidate。範囲外 `uint8_t`、重複カード等の fallback semantics を維持する。
- trusted rule path は、着手開始時に無条件 invalidate しない。
- cache valid 時のみ old salt を XOR-out / new salt を XOR-in。invalid 時は field のみ更新し invalid のままにする。
- partial failure / exception は rollback または invalidate。valid だが誤った hash を残さない。
- bank/player token、bonus/point/count、reserve slot/hidden、visible、noble、control state、deck pop/push/erase を網羅する。
- `CSPLENDOR_VERIFY_INCREMENTAL_HASH`、1,000 seed 以上の random differential、clone/snapshot/determinization/undo を必須とする。
- 採用目安は apply+exact hash 25%以上、exact MCTS 5%以上、CI下限 > 1.01、self-play/legal regress 2%以内、oracle failure 0。

## 現行 exact hash の salt domain

正本は `src/board.h:204-302` の `Board::compute_hash_impl<true,true>()`。

| field | 現行 salt / 特記事項 |
|---|---|
| `bank[6]` | `board.h:210-217`。0もsaltあり。13以上は field-tagged fallback。 |
| `visible[3][4]` | `board.h:219-227`。`-1` は index 0 のsaltあり。範囲外値は現行ではsaltなし。 |
| `nobles` | `board.h:229-235`。slot-sensitive。無効IDはsaltなし。empty slot saltはない。 |
| `decks[3]` | `board.h:237-248`。size saltではなく、各 `(level, position, card)`。無効IDはsaltなし。 |
| player points/counts | `board.h:250-262`。pointsは全uint8、reserved/purchased countは範囲外fallback。 |
| player gems/bonuses | `board.h:263-276`。0もsaltあり。範囲外fallback。 |
| reserve slots | `board.h:277-286`。3 slotすべて、empty `-1` もsaltあり。invalid int8 は `uint8_t` cast後fallback。hidden flagもemptyを含め常にsaltあり。 |
| control state | `board.h:289-299`。current playerはvalid時のみ。waiting saltは `waiting && valid current` の複合条件。final false/winner -1/turn 0にもsaltあり。 |

exact hash対象外だが状態整合性を維持すべきもの:

- `PlayerState::packed_gems`, `packed_bonuses`, `noble_eligibility_mask` はderived (`src/state_field_roles.h:41-54`)。
- `purchased_cards`, `acquired_nobles` はprovenance。同じく exact hash には直接入らない。
- `Game::simple_payment_mode`, `blank_refill_mode` は Board hash外。MCTS keyでは別salt (`src/mcts_game_adapter.h:52-72`)。

## 更新経路の完全 inventory

### 1. 初期化・bulk/raw

1. `Board::init` / `Board::reset` (`src/board.h:47-103`)
   - bank、visible、deck clear/push/shuffle/pop、nobles、players、control fieldsを直接更新。
   - `reset()` が最後に `hash_valid=false`。hot transitionではない。incremental対象にせず、開始時 invalidate の方がexception safety上は明確。
2. `Board::randomize_hidden_information_impl` (`src/board.h:478-530`)
   - `begin_unchecked_mutation()` (`:487`) 後、opponent hidden reserve IDs (`:520`) とdeck全体 (`:525-528`) をshuffle/再構築。
   - position saltが全面的に変わるbulk path。必ずinvalidateを残す。
3. visible-only preprocessing (`src/visible_only_solver.cpp:31-36`)
   - clone後 `begin_unchecked_mutation()` (`:33`) と3 deck clear (`:34-35`)。
   - 必ずinvalidateを残す。

### 2. editor / snapshot

1. `src/board_editor.h:18-117`
   - 全setterはpayload検証/準備後に `begin_editor_mutation()` し、turn/current/bank/visible/nobles/decks/final/waiting/winner/playerを置換。
   - invalid editor request時にvalid cacheを保持する契約が `tests/domain_state_unit.cpp:49-102` にある。変更不可。
2. snapshot deserialize (`src/game_snapshot.cpp:265-372`)
   - 新規 `Board`（初期 `hash_valid=false`）へ全fieldを構築し、`:366` でeditor invalidateしてGameへmove。
   - incremental不要。mode flagsも復元。
3. Python `Board` propertiesは `board_editor` 経由 (`src/bindings_rules.cpp:20-100`)。`PlayerState` はcopy取得→`Board.set_player`でwrite-back。
4. C++ public fieldsへの生書込みは現在もcache gatewayを迂回できる。`tests/state_invariants_unit.cpp:96-112` はこの場合のstale cache検出を明文化している。Phase 1Aで完全防止は不可能で、既存contractを維持する。

### 3. copy / undo / rollback

1. `Game::clone`, `clone_light`, `copy_current_state` (`src/game.h:31-53,199-205`)
   - implicit Board copyで `cached_hash/hash_valid` もそのままコピー。正しい。
   - shuffled cloneはcopy後に上記bulk invalidation。
2. production undo (`src/game.h:158-166`)
   - `board_history` の完全Board snapshotをmove assignment。old cache validity/valueも復元される。
3. action history capture (`src/game.h:208-218,289-295`)
   - mutation前Boardを保存。incremental valid cacheも保存される。
4. solver rollback (`src/visible_only_solver.cpp:227-239,354-363,400-407`; `src/reveal_verified_solver.cpp` の多数の `previous` capture/assignment)
   - Board assignmentによりcacheも完全復元。
5. debug `UndoRecord` (`src/undo_record.h:48-129`)
   - cache value/validityをcapture (`:78-79`) し最後にrestore (`:126-127`)。
   - normal Game deck mutationがtop-popだけという前提でdeck dataは保持しcountのみrestore (`:103-104`)。Phase 1Aでdeck内容を書き換えないこと。
   - restore途中はpost-actionのvalid cacheを保持したままfieldを書き戻すが、外部callback/throwはない。将来production化するなら最初にinvalidateし、最後にcaptured cacheを復元する方が安全。

### 4. Game entry / transaction boundary

全公開入口 `Game::apply`, `apply_trusted`, packed code/index/random/pass (`src/game.h:56-66,103-155`) は `Game::apply_unchecked` (`:208-297`) に集約される。

- 現在 `board.begin_unchecked_mutation()` (`:220-221`) が全action開始時に無条件invalidate。
- false return箇所: noble failure (`:240-241`)、default (`:278-279`)、各apply failure (`:282-283`)。
- history vector allocation exceptionはBoard mutation完了後にも起こり得る (`:293-295`)。
- incremental実装では successful commit と failure/exception invalidate を区別するRAII guardが安全。

### 5. take / token return

1. `Game::apply_take_gems` (`src/game.h:435-443`)
   - current player's `gems[0..4]` (`:438`)、bank `[0..4]` (`:439`)。
2. `return_gems_unchecked` (`src/rule_transition.h:29-37`)
   - player gems/bank 全6色 (`:32-35`)、packed gems再同期 (`:36`)。
3. `return_gems_checked` (`src/rule_transition.h:39-53`)
   - color順にmutationし、後のcolorで失敗可能 (`:45-50`)。partial failure時はcache invalidate必須。packed fieldもfailure時は未同期だが呼出側はbranchを破棄/restoreする。

同じ色をtake後にreturnする合法手があるため、個別deltaを逐次正しく合成するか、最終値を一度だけcommitする必要がある。

### 6. reserve visible / deck

1. reserve slot append (`src/rule_transition.h:15-19`)
   - `reserved_is_hidden[count]`、`reserved[count]`、`reserved_count`。
   - hashはcount以外にも全3 slot/hiddenを常時含む。editor-created inconsistent slotもold saltを正しく除去する必要がある。
2. visible reserve (`src/game.h:445-470`)
   - player reserve append。
   - deck non-empty: top pop (`:458/:462`) とvisible old→blank/new top (`:459/:461`)。
   - deck empty: visible→`-1` (`:465`)。
   - blank refillでもtop card saltは除去する。
3. deck reserve (`src/game.h:473-483`)
   - top card read/pop (`:478-479`)、hidden reserve append。
4. reserve gold (`src/rule_transition.h:21-27`)
   - bank gold--、player gold++。後続return helperがpacked gemsを同期。
5. token returnは上記helper。

通常deck popのdeltaは `old n`, `card=deck[n-1]` の1 salt除去のみ。exact hashにはdeck-size saltはない。

### 7. purchase

1. payment/card gain (`src/rule_transition.h:55-100`)
   - 5色のgems/bank (`:64-77`)、gold gems/bank (`:78-85`)。
   - provenance vector push (`:90`)、purchased_count (`:95`)、bonus (`:96`)、points (`:97`)、packed/eligibility sync (`:98`)。
   - `ValidatePayment=true` は後のcolor/gold検証でpartial failure可能 (`:58-60,68-81`)。
   - `purchased_cards.push_back` はpayment後にthrow可能。outer transaction guardがcacheをinvalidateすべき。
2. reserved source removal (`src/game.h:509-517`)
   - selected slot以降をleft shiftし、slot2をempty/hidden false、reserved_count--。
   - exact hashはslot-sensitiveかつhiddenを常時hashするため、全3 slot tupleをold/newでdeltaするのが安全。
3. visible source refill (`src/game.h:518-533`)
   - reserve-visibleと同じtop pop + visible replacement/blank/empty。

trusted APIはPythonにも公開され、editor-created inconsistent countや範囲外resource値に対してもwrap後の現行fallback semanticsを維持する必要がある。

### 8. noble / waiting noble

1. `Game::apply_noble_visit` (`src/game.h:541-568`)
   - eligible selection後 `acquire_noble_unchecked`。
2. `acquire_noble_unchecked` (`src/rule_transition.h:102-114`)
   - points (`:104`)、acquired provenance push (`:108`)、`board.nobles.remove` (`:113`)。
   - vector pushはpoints更新後にthrow可能。
   - noble hashはslot-sensitive。任意slot removalで後続全nobleがshiftするため、removed ID saltだけのXORでは誤る。small list全体のold/new deltaが必要。
3. `finish_standard_action` (`src/rule_transition.h:133-142`)
   - eligible >1なら `waiting_noble=true` (`:135-137`) してturnを終了しない。
   - eligible ==1ならauto acquire後end turn。
4. explicit noble branch (`src/game.h:238-251`)
   - acquire後 `waiting_noble=false` (`:242`) してend turn。

### 9. turn / final / winner / forced pass

1. `end_turn` (`src/rule_transition.h:120-131`)
   - acting playerが15点以上ならfinal=true (`:121-122`)。
   - current player toggle (`:124`)。
   - player 1→0の時だけturn++ (`:128`)。
   - final roundならwinner更新 (`:129-130`, `check_game_end :116-118`)。
2. waiting saltは `waiting_noble && current_player` の複合salt (`src/board.h:291-295`)。current playerだけをXORするとwaiting=true時に誤る。control state全体のold/new delta、またはcurrent setter内でwaiting saltも更新する。
3. PASS (`src/game.h:252-277`)
   - live boardから `next` copy (`:258`)、`end_turn(next)`、双方forced passなら `next.winner=-2` (`:267`)、move assignment (`:268`)。
   - live Board用guardだけではnextのcacheを管理できない。nextにもtrusted guardを作るか、passは明示invalidate fallbackにする。正本の「successful trusted apply直後valid」まで満たすならnextもdelta維持する。

### 10. exact reveal / solver独自mutation

1. arbitrary deck erase (`src/reveal_verified_solver.cpp:894-904`, `remove_card_from_deck`)
   - 任意位置eraseは後続position saltをすべてshiftする。
2. visible reveal outcome (`:906-923`)
   - arbitrary erase (`:910`)→同cardをtopへpush (`:912`)→normal `Game::apply_trusted` がtop-popしてvisibleへ置く。
   - 現在erase/push前にはmutation gatewayがない。Game側の無条件invalidateを外すと、ここでcache validのままdeckが変わる。`remove_card_from_deck` が成功直前にinvalidateするのが最も局所的で安全。
3. deck-reserve reveal outcome (`:925-950`)
   - `begin_unchecked_mutation` (`:938`)→arbitrary erase→reserve/gold/checked return/finish。
   - bulk/raw invalidate pathを維持する。
4. oracle action (`:1321-1358`)
   - `begin_unchecked_mutation` (`:1326`)→validated purchaseまたはsynthetic reserve→finish。
   - partial failure helperを含む。exact solver state keyはset-deck hashであり、Phase 1A exact cache維持の便益が小さいため、初期実装ではinvalidate fallbackが安全。
5. 全solver branchはBoard snapshot assignmentでrollbackする (`:609-615`, `:624-631`, `:645-653`, `:671-718` 等)。cacheも復元される。

## 最重要の更新漏れリスク

1. **`begin_unchecked_mutation()` の意味を単純変更しない。** 現在のcallerは:
   - normal Game apply (`game.h:221`)
   - PASS copy (`game.h:259`)
   - determinization bulk shuffle (`board.h:487`)
   - visible solver deck clear (`visible_only_solver.cpp:33`)
   - exact solver arbitrary erase (`reveal_verified_solver.cpp:938`)
   - oracle synthetic transition (`reveal_verified_solver.cpp:1326`)

   safest案は既存 `begin_editor_mutation` と既存/raw `begin_unchecked_mutation` のinvalidate semanticsを残し、Game normal path専用 `TrustedMutator` / transactionを追加すること。既存関数をtrusted化するなら、残り5callerを明示的なbulk-invalidating gatewayへ全移行する。
2. **visible empty saltを入れ忘れない。** card→`-1` はold card salt除去だけでなく `cards_board[...,0]` 追加が必要。
3. **reserve empty/hidden saltを入れ忘れない。** empty slotにもcard saltとhidden=false saltがある。
4. **noble/reserve shiftを単一要素deltaにしない。** slot-sensitive saltの後続全要素が変わる。
5. **waiting/current coupling。** current toggle時にwaiting saltのplayer indexも変化し得る。
6. **deck exact hashにsize saltを誤追加しない。** normal popはtop positional saltだけ。observable hashのdeck-size semanticsと混同しない。
7. **arbitrary deck eraseをtop-pop helperで処理しない。** exact reveal pathはinvalidate fallbackまたはshift range全delta。
8. **fallback saltをcanonical table accessだけで置換しない。** bank/gems/bonus/count/reserved invalid値は現行 field-tagged fallback。visible/noble/deck/current invalid値は現行saltなし。
9. **signed int8 semantics。** visible `-1` はindex 0。reservedのinvalid negative値は現行 `uint8_t` cast後fallback。
10. **failure/exception。** `return_gems_checked`, `purchase_card<true>`, provenance vector allocation、history vector allocationでpartial/exceptionがある。RAII uncommitted destructorでinvalidateする。
11. **invalid cache pathでZobristを触らない。** self-play without hashを悪化させないため、`hash_valid==false` ならfield更新だけにする。validならZobrist singletonは既に初期化済み。
12. **salt helperの二重実装を避ける。** `compute_hash_impl` とdelta側が同じfield salt関数を使わないとfallback/empty semanticsが将来driftする。

## 推奨する安全な実装境界

1. Board内にexact field salt関数を作り、full recomputeとdeltaの双方から使う。
2. Game normal transition用RAII transactionを作る。
   - construction時の `was_valid` を保持。
   - invalid開始なら全setterはfield-only。
   - valid開始ならtyped mutation primitiveでcacheを更新。
   - `commit()` されないfalse return/exceptionではinvalidate。
3. mutation primitiveの最小group:
   - bank / player gem / bonus / points / reserved count / purchased count
   - visible slot
   - reserved 3-slot tuple + hidden + count
   - noble list whole-small-list delta
   - control tuple `(current,waiting,final,winner,turn)`
   - deck top pop/push
4. `remove_card_from_deck` は成功直前にinvalidateして任意eraseを隔離する。determinization/visible-only/oracle pathsもbulk invalidateを維持する。
5. PASSの`next`は別transaction、または安全なinvalidate fallbackを明示する。

## 必須テスト観点

- pre-hashをwarmした状態で全合法 action を適用し、successful apply直後に `hash_valid` と `cached_hash == compute_hash_uncached()`。
- invalid cache開始ではapply-only後もinvalidを維持し、最初の `hash()` がoracle一致。
- TAKE_DIFFERENT/TAKE_SAME、同色take+return、全6色return。
- reserve visible/deck、normal/blank/empty refill、gold有無、return有無。
- purchase visible/reserved、reserved slot 0/1/2 shift、hidden flag、normal/blank/empty refill、gold payment各pattern。
- noble 0/1/複数、auto visit、waiting→explicit visit、noble removalの先頭/中間/末尾。
- final round開始、player toggle、turn increment/wrap、winner 0/1/draw、one/two-sided forced pass。
- editor wide uint8 fallback、duplicate/odd reserved layout、failed trusted action、partial checked helper、allocation exception injection。
- determinization後、visible-only deck clear後、exact reveal arbitrary erase後にcache invalidであること。
- clone/full/light、snapshot roundtrip、production undo、UndoRecord、solver Board rollbackがcache validity/valueを含め一致。
- 1,000 seeds以上、simple/full payment、blank refillを交差し、ordered legal listとfull Board fieldをA/B比較。

## 監査結論

normal Game pathは局所的で、top deck popを除けば全更新fieldをtyped primitiveで覆える。最大の実装事故要因は、通常着手とbulk/solver mutationが共有する `begin_unchecked_mutation()`、slot-sensitiveなnoble/reserve shift、waiting/current複合salt、exact revealの任意位置deck eraseである。これらをinvalidating fallbackとして明示分離すれば、Phase 1Aは安全に実装可能。
