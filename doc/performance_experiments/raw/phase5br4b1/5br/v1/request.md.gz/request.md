# csplendor 高速化実装・効果検証依頼書 第2版
## Phase 3C完了後の再計画 — 2026-09-05

**対象:** `kuboyoo/csplendor` / C++17 / CMake / pybind11  
**旧計画:** `doc/csplendor_codex56_engine_optimization_request.md`  
**今回の目的:** 完了済みPhaseをやり直さず、残りの最適化を、実測・互換性・実装費用に基づいて再設計する。

> 本書は旧計画の未着手部分と採否規約を置き換える。Phase 0〜3Cの採用コード・棄却記録は維持する。初回は **R0：ローカル成果物との照合・限定再測定** だけを実施し、次の独立チケットを一つ提案して停止する。Phase 0の計測基盤を再作成してはならない。

## 0. 根拠・到達点・未確認事項

### 0.1 今回の参照範囲

| 区分 | 内容 |
|---|---|
| ユーザー申告 | **Phase 3Cまで完了済み**。これを進捗上の前提とする |
| 旧計画の基準 | `7835f642b23251d0cb91de180006084521c74aa6` |
| 今回取得できた公開作業ブランチ | `perf/codex56-engine-hotpaths` |
| 同ブランチの参照コミット | `0c5eba654ab4536c70947e725872cf5790db5e92`（以下 `REVIEW_REF`） |
| 公開側で内容を確認できた実験記録 | Phase 0、1A、1B、2A、2B、3A。3A報告の次工程は3B |
| 未確認 | ユーザーのローカル3B・3Cコード、採用したTT方式、測定結果、未コミット差分 |
| このレビューで未実施 | Phase 3C後のエンジンのビルド、性能測定、全回帰テスト |
| このレビューで実施 | 公開ソース・採否記録の横断読解と、小さな独立した意味論プローブ。詳細は付録B |

**「3C完了」は「旧計画の全提案を採用した」という意味ではない。** 3C内の一部棄却や、unordered_map維持も正常な完了である。以下の変更案は、ローカル3B・3Cに同等の改善がないことを確認した場合だけ実装する。

本書の根拠は、末尾の `[Sxx]` がリポジトリ資料、`[Txx]` が外部一次資料。資料に記録された数値は、その資料の当時のfixture・ビルドに限定される。本書で新しく提案する効果は未測定であり、予測倍率を約束しない。

### 0.2 今回確認できた採否を引き継ぐ

| 項目 | 記録に基づく判断 | 再計画への反映 |
|---|---|---|
| exact hash差分更新 | 採用。apply+hash 1.6467倍、exact legacy 1.0844倍という当該A/B | 再実装しない。新rollbackは既存hash transactionと整合させる [S02] |
| observable hash差分更新 | **棄却・revert**。legacy中盤1.0148倍、CIが1を跨ぐ。hidden reserve 0.9969倍 | 「1B完了だからcacheがある」と仮定しない。別設計・新profileなしに復活させない [S03] |
| packed gems/bonuses差分更新 | **棄却・revert**。購入microは改善したがapply+exact hashなどが悪化 | 全mutatorへの再導入を計画しない [S04] |
| legal codes単回生成 | 採用。既存の16 KiB scratchと、公開上限・列挙順を保持 | 旧5Cの同じ提案は完了扱い [S05] |
| return count / return pattern table | 実験記録がある。採用状態はR0でsource/flagsと照合 | 全面的なgenerator書き直しをしない |
| purchase候補pattern table | **棄却・revert**。約12 KiBの表でもgold-payment codesは1.0072倍 | 同じruntime filter型LUTを再試行しない [S06] |
| bounded recursion path | 採用。一方、無制限visible minimaxは最大108 plyのためhash setを維持 | 全pathを固定深さstackへ変えない [S07] |
| card equivalence class | 採用。現行90枚は全て別class。集合実装の軽量化が効いた | 枝数削減による効果と説明しない [S07] |
| Phase 3A全体 | 当該exact-reveal fixtureで1.2786倍、allocation calls 3,211,048→1,281,407 | 3Dの余地は残り得るが、Phase 0のallocation比を現状の値として使わない [S07] |
| Phase 3Aのmap single lookup案 | 中立でrevert | `try_emplace`への機械的置換を再提案しない [S07] |

旧READMEの約544万nodes/sと、3A報告の約64万nodes/sは別workloadであり、退行・改善率として直接比較しない。

---

## 1. 旧計画から変更する重要事項

### 1.1 正しさの検証を三種類に分ける

**S0：意味と決定的実行順を保存する実装最適化**  
固定入力・固定予算・固定浮動小数規則・同じcache初期状態では、solverの結果、訪問順、node数、合法手数、TT hit、主手順を一致させる。実装都合のcopy数、allocation数、key再計算数は減ってよい。公開状態と内部cache validityの違いは区別する。

**S1：非同期throughput実装の最適化**  
共有木のthread schedulingは変わり得る。throughput modeのroot visits配分、木サイズ、評価重複件数の完全一致をA/Bの合否条件にしない。別途deterministic epoch oracleで論理操作の一致を確認し、throughputでは実完了件数、unique evaluation、整合性、停止理由、品質を評価する。

**S2：探索方針・数値規則を変える実験**  
move ordering変更、pruning、TT eviction方針変更、virtual-loss式の数値的変更、推論batch方針変更など。S0と同じ表で「同じ探索を高速化した」と報告しない。別チケット・別品質gateとし、本書の初回実行対象にはしない。

### 1.2 root-parallelはlegacy treeではない

`run_root_parallel()`は各workerで`ParallelMCTSSearcher`を`DeterministicEpoch`、`num_threads=1`で動かす。したがって旧4Bのlegacy三重map統合がroot-parallelに直接効くとは限らない。旧4A/4CのConcurrentTree改善とworker Game再利用の方が実行経路に合う。[S09]

### 1.3 reservationは「たいてい0〜4個」と仮定しない

Phase 0の4-thread / batch16 / 256 simulationsというinstrumented sampleで、node内同時reservationは最大31、488 sample中252が4以上だった。少なくともinline 2〜4要素だけで十分とは言えない。[S08]

これは当該runの観測であり現行分布ではない。root/内部node別、batchとmax_inflight別の分布を取り直す。allocation削減のためにtoken検証やoverflow判定を捨ててはならない。

### 1.4 virtual lossの合計置換はbitwise同値ではない

現行の `sum(double(vl_i) * 0.3)` と `double(sum(vl_i)) * 0.3` は、実数演算では同じでも浮動小数では異なる。独立プローブでは、6本に1ずつのVLがある場合に`1.8`と`1.7999999999999998`になった。[S10 / 付録B]

旧4Aの「total_virtual_lossを持てばそのまま全scan除去」は、S0の既定案から外す。最初は加算順と型を保った走査を残し、検索・allocation・不要atomicを削る。数値変更が必要ならS2として扱う。

### 1.5 legacy compact nodeには公開mutable APIの壁がある

`get_node()`は`MCTSNode*`、`get_or_create_node()`は`MCTSNode&`を返す。単に内部を疎なedge構造にして、外へ一時的dense DTOを返すだけでは、保持pointer経由の更新という既存意味を保てない。[S11]

三重map統合は進められるが、dense node廃止は後回しにする。compatibility mirrorを導入して両方保持すると省メモリ効果を失い、外部からの書込みの同期も難しい。APIの非互換変更なしに成立する設計を提示できなければStage 2は実施しない。

### 1.6 containerの参照安定性を正しく扱う

`std::unordered_map`のrehashで無効化されるのはiteratorであり、要素へのpointer/referenceは無効化されない。eraseされた要素やmap破棄は別である。一方、移動を伴うflat tableではその保証を一般に引き継げない。[T01]

3Cがflat TTを採用済みなら、再帰中に保存していたentry pointer/referenceが次のinsertやgrowを跨ぐ箇所をR0で確認する。entryを値で取り出す、keyで再lookupする、stable arenaを使うなど、現行設計に合わせる。旧planの「unordered_map rehashだから全pointer禁止」という誤った説明は使わない。

### 1.7 LTOは「まだ未導入」と決めつけない

pybind11の`pybind11_add_module`は通常ReleaseでLTOを追加する。実際の有効性はpybind11版、CMake設定、compiler対応で変わる。Python拡張とnative benchmarkのflagsを別々に監査してからLTO案を評価する。[T02]

---

## 2. ゴールと実行経路を先に固定する

速くすべき対象を混同しない。

| 系統 | 主な測定単位 | 主な候補 |
|---|---|---|
| ルール・自己対戦 | moves/s、合法code列挙/s、選択index適用/s | full-action生成、rank選択、buffer境界 |
| native MCTS 48手 | completed simulations/s、path steps/s、実NN込み所要時間 | ConcurrentTree、scratch Game、48-index適用 |
| V3連携 | V3 mask/encode/decode、バッチ環境step、学習runner所要時間 | V3 codecの静的DP、additive buffer API |
| visible-only | 固定探索の時間、allocation/node、ピークRSS | child代表化、rollback、temporary buffer |
| exact reveal | 同じ探索の時間、allocation/node、実際に訪問しためくれ数 | scoring再利用、rollback、共通着手prefix |
| anytime session | 持ち時間内の証明到達率、初回証明時間、session全体RSS | persistent TTとの相互作用、反復呼出し費用 |

48手とV3の3133手は同じ行動表現ではない。V3 codecを改善してもnative48 MCTSへの直接効果は主張しない。逆に48-index特化でfull-action solverの支払い・返却分岐を省略してはならない。

`max_cache_states`や`max_tree_nodes`も同じ契約とは限らない。solverのcache上限が「solve前後のtrim」なのか「探索中のhard cap」なのかはローカル3Cの実装を正とする。性能変更に紛れて到達時のstop reasonやUNKNOWN化を変えない。

---

## 3. 実行順と旧Phase対応

番号順の消化より、観測された費用を減らすことを優先する。

| チケット | 内容 | 旧計画との関係 | 着手条件・優先度 |
|---|---|---|---|
| **R0** | ローカル3B/3Cの採否・契約・現在の主workloadを確認 | 新規。Phase 0のやり直しではない | 必須・最初 |
| **3D-P1** | めくれ候補scoreをsort比較中で再計算しない | 新規・3D前処理 | 未実装なら優先。低リスク |
| **3D-P2** | 再帰frameごとの候補buffer再利用 | 旧3Aの残課題を限定化 | allocation profileで根拠がある場合 |
| **4A-1** | ConcurrentTreeの未使用access metadata削除 | 旧4Aを独立化 | consumer不在確認後。低リスク |
| **4A-2** | compact edgeの反復binary search除去 | 旧4Aを具体化 | root-parallel/sharedが重要なら優先 |
| **3D-1** | solver内の通常着手用transactional rollback | 旧3Dの第一段階 | copy/allocatorが現行でもmaterial |
| **3D-2** | arbitrary reveal向けのdeck patchとnested rollback | 旧3Dの第二段階 | 3D-1のoracle通過後 |
| **3D-3** | 着手共通部分1回＋めくれごとの差分適用 | 新規 | 実訪問めくれ数と共通処理費用が十分大きい |
| **5B-R** | worker/caller専用Game scratch再利用 | 旧5Bを安全な先行案へ変更 | clone allocationがmaterial |
| **4B-1** | legacy node/aux/accessのrecord統合 | 旧4B Stage 1 | 実際にlegacyを利用している場合 |
| **4C-1〜3** | diagnostic counters、token storage、lockの個別最適化 | 旧4Cを分割 | 4A/5B後にも競合が残る場合 |
| **5D** | V3の静的composition DP | 新規 | V3呼出しが実workloadにある場合 |
| **3E** | visible-onlyのtake手代表化の事前grouping | 新規 | 代表化のapply費用が上位の場合 |
| **5E** | full-actionのrank選択・unrank | 新規 | 自己対戦の選択prefix列挙が上位の場合 |
| **5A** | 48-indexの直接適用 | 旧5A | decode/source lookup費用が残る場合 |
| **5C-B** | Python buffer API・immutable feature table | 旧5Cの残課題＋新規 | 境界費用が上位の場合 |
| **6** | native/LTO/PGO | 旧6を監査先行へ変更 | build監査は早期可。最終測定は採用code統合後 |
| 保留 | legacy dense node廃止、provenance廃止、persistent worker pool、lock-free queue | 旧4B後半/4D/5B後半 | 下記条件を満たさない限り実装しない |

R0の後は、solver重視なら3D-P1→3D-1→3D-2、MCTS重視なら4A-1→4A-2→5B-Rを基本順とする。両方を同時に大改造しない。3D-3は3D-2が速くなった後に再評価する。

---

## 4. R0：完了済み3Cとの照合

### 4.1 作業指示

最初にAGENTS.md、旧計画、現行コード、実験報告を読む。

```bash
git status --short
git rev-parse HEAD
git log -12 --oneline
git diff --stat
find doc -type f \( -iname '*phase3b*' -o -iname '*phase3c*' -o -iname '*handoff*' \) -print
```

**checkout、reset、stash、ユーザー差分のrevert、pushは禁止。** branchを切る場合も現在の成果物を基準にする。3B/3Cが未コミットなら、HEADだけから作ったworktreeを「3C完了baseline」として使ってはならない。対象ファイルの内容hashと差分hashを記録し、現行内容を保持する隔離copy等で比較する。

次のmanifestを作る。ファイル名は新設可だが既存report schemaを壊さない。

```text
doc/performance_experiments/post3c_review_baseline_<date>.md
```

必須内容:

- BASE_COMMIT、未コミット差分の有無、source tree digest。
- 0〜3Cの各案について ACCEPT / REJECT / NOT_IMPLEMENTED / UNVERIFIED。
- 3B sidecarの型、所有者、構築・更新・復元関数、対応mode、fallback条件。
- 3C TTの型、key equality、entry lifetime、grow/trim方針、深さ・mode・root依存情報の範囲。
- cold/warm persistent sessionの初期化条件、capacity contract、reference backendの残存状況。
- 現行Board/Gameのfield一覧、sizeof、hash/cache状態の契約。
- 新3Dのために復元が必要な全field、モード、provenance、sidecarの一覧。
- 実際に主要runnerが使うlegacy/shared/root-parallel、48/V3、NN evaluatorの種類。

### 4.2 計測は限定して既存harnessを使う

最初からbackend×threads×batch×latency×全fixtureの直積を回さない。既存のrunnerを読み、現在HEADで次の代表sliceを短く再確認する。

1. exact reveal：既存のdeep・shallow・warm sessionから代表3つ。
2. visible-only：通常fixtureと長いtoken cycleを含むfixture。
3. MCTS：現在使うbackendの1Tと主要thread数。determinizedを含む。
4. clone/reset allocationと、candidate scoring回数。
5. V3利用がある場合だけV3 encode/mask。

hardware counterが禁止されていれば未取得と記録する。過去同様の`perf_event_paranoid=4`を勝手に変更しない。gprofやinstrumentationの比率を「cycles比率」に読み替えない。Phase 0の合成hotspotランキングをPhase 3C後の順位として使わない。

### 4.3 R0完了条件

新3D/4Aに必要なローカル契約を言語化し、既に実装済みの新提案を除外する。次に試すチケット一つ、primary metric、reference path、回帰fixtureを提案して停止する。

3B/3Cの成果物が作業環境にもなければ、推測で再実装しない。どのfile/commitが必要かを報告して、その依存チケットだけ止める。

---

## 5. 3D-P1：めくれ候補scoreの一回計算

### 根拠

公開ソースの`order_visible_refill_cards_by_blank_probe()`は`std::sort`の比較関数で、左右cardそれぞれの`reveal_counterexample_score()`を再計算している。`deck_reserve_cards()`の守備側sortも同様に`defender_reserved_card_threat_score()`を繰り返す。scoreには支払い可否・不足数・貴族獲得点などの計算が含まれる。[S12]

### 変更案

候補生成後に、各cardについて一度だけ`{score, card_id}`を作る。sortは現行どおり **score降順、card ID昇順** の整数比較だけで行う。その後、現行と同じ順のcard列へ戻す。

- score式、候補集合、同型代表のfirst-seen規則を変更しない。
- node/action-localな再利用に限定する。別局面を跨ぐglobal score cacheは作らない。
- 特にreserveの返却色が違うとafter-gemsが変わるので、異なるactionへ無条件共有しない。
- `cards.size() <= 1`、blank probe失敗、終局・貴族待ちの挙動を維持する。
- normal deckの上限が証明できる場合は小さな固定scratch。editor入力は安全なfallback。
- 3Bですでに同じ改善が入っていればSKIP_ALREADY_DONE。

### 検証・採否

全候補について旧scoreと新score、sort後のcard列を比較する。固定探索のnode/TT/主手順も一致させる。score-call数の削減を機序として確認し、solver全体の時間で採否を決める。candidate生成数が多くても訪問数が小さいfixtureを含める。

このチケットにrollbackや新TTは混ぜない。

---

## 6. 3D-P2：深さ別scratchを用いたtemporary allocation削減

### 変更案

一つの再帰呼出しが所有するordered actions、scored reveal candidates、temporary outputを`SearchScratchFrame`へまとめ、同じ深さで再利用する。sharedな一本のvectorを全再帰で使わない。

親の配列へのreferenceを保持したまま、外側`std::vector<Frame>`をgrowするとframe移動で壊れる可能性がある。固定上限が証明できる経路だけ事前確保し、その他は安定addressを持つchunk/個別frame所有等にする。無制限visible minimaxを「詰み深さ8だから8 frame」と見積もらない。

- `clear()`によるcapacity再利用と、新しいfixed bufferを比較する。
- 各frameに2048個のwide Actionを常設してstack/RSSを増やさない。
- memory footprintは最大深さ×frame capacityで報告する。
- 初回確保・warm反復の両方を測る。
- inline bufferを導入する場合、0/少数/多数の分布から容量を選ぶ。
- split_root/frontierの返却Gameやproof DAGはcaller所有のままにし、scratchへの参照を返さない。

---

## 7. 3D-1：solver内部のtransactional rollback

### 7.1 目的と境界

公開`Game::undo()`は変更しない。solverの同一再帰branch内だけで、必ず適用と復元が対になるRAII transactionを導入する。

まず通常手とvisible-onlyの限定経路から始め、任意位置deck操作は3D-2に分ける。いきなり公開Boardを新しい全purpose state型へ置き換えない。

### 7.2 最初から最小deltaを追わない

比較する実装は以下の順。

1. referenceのfull Board copy/restore。
2. **非vectorの小さなrule snapshot＋provenance長さ＋必要なdeck内容**。
3. action type別のさらに小さなdelta（2が十分速ければ不要）。

最も重要な仮説は「392 byte前後のcopyを数byte減らすこと」より、購入・貴族provenance vectorのdeep copyと確保を枝ごとに繰り返さないことである。現行sizeofはR0の値を使う。[S07/S13]

### 7.3 復元contract

R0で実際の全fieldを埋めた復元表を提出する。

| 状態 | capture/restore方針 |
|---|---|
| bank、visible、nobles | old valueまたは変更範囲を保存。貴族listの順序も保存 |
| acting playerのgems/bonuses/points/reserved等 | old scalar/array。予約slotのshiftとhidden flagも復元 |
| purchased/acquired provenance | 通常遷移がappend-onlyであることを確認し、old lengthへtruncate |
| packed値、貴族mask | authoritative arrayだけでなく現行derived-state契約も保存 |
| current_player、turn、winner、final_round、waiting_noble | 全て保存。貴族選択では手番が直ちに変わらない場合がある |
| Game mode | 一時変更する`blank_refill_mode`等はscope guardで必ず復元 |
| exact hash | candidate transaction/validityを尊重。invalid時のcached数値とvalid hashを混同しない |
| 3B sidecar | remaining/claimed/acquired/rule hash等、実装に存在する全更新を逆操作またはsnapshotで復元 |
| 3C TT | branch rollbackでTT自体を巻き戻さない。学習済みentry、touch、cache再利用は現行規則を維持 |

原則、探索で変更しない相手playerは保存不要。ただしそれをcall graphとテストで証明する。特殊手が両playerを変更するならその手だけ別snapshotにする。

### 7.4 RAII設計要件

概念API（実際のsymbol名は現行に合わせる）:

```cpp
{
    SolverBranchGuard guard(game, solver_state, action_descriptor);
    if (!apply_branch(...)) {
        // destructor restores all branch-local state
        return failure;
    }
    visit_child(...);
} // restores on normal return, early break, exception and cancellation
```

- guard構築中に必要な確保を済ませ、以後のrestoreは割当不要・`noexcept`で行える設計。
- vector全体への`memcpy`/`memcmp`は使わない。
- truncate前に現在sizeがold size以上であるというappend-only invariantを検査する。途中で消去もする経路にはこの方式を適用しない。
- guardのdestructorでchecked card lookup、vectorの成長、例外送出を行わない。
- `apply=false`でも部分mutationがあり得る。successful pathだけrestoreする設計にしない。
- 例外を捕まえて通常のREFUTED/引き分けへ変換しない。
- 3Bが既に持つguardとの二重復元を避け、所有者を一つに決める。
- `Board::RuleMutator`の寿命とrollback順を明示する。未commitのhash candidateがrestore後にpublishされないようにする。

### 7.5 oracle

各branchで親状態をreference snapshotに保持し、適用後はreference child、復元後はreference parentと比較する。

比較は意味を持つ全field、active deck順、provenance内容、valid hash、sidecarを対象とする。vector capacityやstruct paddingは意味論ではなく性能指標として別記する。snapshot形式が内部cacheやsidecarを保存しない場合、serialization一致だけで検証を終えない。

注入箇所は、支払い途中、provenance append後、source除去後、貴族処理後、hash commit前後、visitorの最初/途中/最後。通常return、false、throw、node limit、cancelをそれぞれ試す。

---

## 8. 3D-2：任意位置deck操作の復元

公開ソースのexact revealは、選択cardをdeck内で探し、eraseし、一時的にtopへpushして通常applyする。**deck countだけを戻しても元の順序は戻らない。**[S12]

### 8.1 第一候補：触る山だけ保存

最大40枚という現在の型では、まず対象levelのactive card列とcountだけを保存する方式を試す。約40 byteのコピーを避けるために複雑な逆shiftを先に書く必要はない。

- 触らない2山はcopyしない。
- 任意位置erase＋push＋pop、空山、最後の1枚、先頭/中央/末尾を検査。
- 同じlevelへ再帰的に入る場合、各guardが独立してその深さの親を保持する。
- inactive領域やcount復元後に再びactiveになる位置の必要性を現行実装に照らして定義する。
- exact/set-deck hash、deck bitset、visible/reserved IDをまとめて復元する。

### 8.2 第二候補：erase patch

第一候補がまだhotな場合だけ、`{level, index, removed_card, old_count}`等によるinverse shiftを検討する。最小deltaの正しさを推測で済ませず、active deck列を全照合する。

**swap-removeで山順を変えて高速化する案は、S0では採用しない。** set-deck TTが山順を無視していても、候補列挙順、代表めくれ、snapshot、public exact hashには順序が関係し得る。

### 8.3 適用範囲

通常Game手、visible refill、deck reserve、oracle手を別々にgateする。検証できていないeditor/overlap状態はreferenceへfallbackする。fallbackの有無で公開結果や例外規則を変えない。

---

## 9. 3D-3：共通着手prefixとchance部分の分離

### 9.1 新しい高速化仮説

現行のvisible refillでは、同じ購入についてめくれcardごとに支払い、bonus/points更新、履歴append、貴族処理などを繰り返す。[S12]

これを、**公開の通常着手と補充処理を丸ごと二重実装せず**、内部の共通rule primitiveを用いて分離する。

```text
parent
  └─ action-common preparation, once
       ├─ install reveal c0 → recurse → restore prepared state
       ├─ install reveal c1 → recurse → restore prepared state
       └─ ...
  → restore parent
```

準備状態は探索局面ではない。TT lookup、終局判定公開、feature生成、proof出力へ渡すのは、めくれを含む全遷移が完了したchildだけとする。

### 9.2 blank_refill_modeをそのまま流用しない

既存blank refillは「任意cardを後で入れるだけ」ではなく、実際のdeck topを消費する。一度blank applyした後に別cardを消費すると、2枚消費したり誤った残存集合になる。

明示的なdeferred refill descriptorを設計するか、最初の具体childから正確な逆patchを作る。どちらも、各cardについてreference childの **deck順、残存集合、公開面、provenance、hash、sidecar、手番・貴族・終局** と完全一致を証明する。

### 9.3 最初はvisible purchaseのみ

- reachable/validated stateのvisible purchaseだけをopt-in対象にする。
- 同じscore order、同じcandidate list、同じearly cutoffを維持する。
- VISIT_NOBLEは補充cardと独立でも、待ち状態と残り攻撃手数の意味を保存する。
- final-round direct resolutionや既存のreveal collapseを新たに置換しない。
- reserve_visible、reserve_deck、oracleは別チケットにする。
- `simple_payment_mode`を有効化して支払いパターンを減らしてはならない。

### 9.4 採否に必要なcost model

生成候補数を`r_generated`、実際に探索した数を`r_visited`とする。

```text
reference ≈ r_visited × common_apply_cost + reveal_patch_costs
candidate ≈ common_apply_cost + preparation_overhead + reveal_patch_costs
```

平均候補30枚でも、ほとんど1枚目で反駁できるなら利得は小さい。両方の分布、共通apply回数、restore回数を測る。3D-2によってcopy費用が既に小さくなった後で、追加複雑性に見合うか判断する。

このPhaseはchance分岐を省略する最適化ではない。全めくれ検証の意味は変えない。

---

## 10. 4A：MCTS selectionの構造的な無駄を削る

### 10.1 4A-1：write-only metadata

`ConcurrentTree::find/find_or_create`はglobal `access_epoch.fetch_add`とnodeの`last_access.store`を実行する。[S10]

現行checkout全体でconsumerを検索する。

```bash
rg -n 'access_epoch|last_access' src tests scripts doc
```

eviction、snapshot、trace、public consumerがない場合だけ、ConcurrentTree側の2 fieldと更新を削除する。legacyの`access_count_`はpruneに使われる別物なので削除しない。過去資料にある予定用途だけで現在のhot path書込みを維持する必要はないが、削除対象のAPI境界を明示する。

### 10.2 4A-2：binary searchを繰り返さない

compact edgesはaction昇順、union maskはその集合である。次の三方式を単独比較する。

**A. bit-rank**

```cpp
// Preconditions: 0 <= action < 48; union contains action.
index = popcount(union_mask & ((uint64_t{1} << action) - 1));
```

C++17なので既存のportable popcount helperを使う。C++20の`std::popcount`を無条件導入しない。

**B. sorted edgeとworld maskのmerge走査**  
候補ごとのrankも省き、edge順とset-bit順を合わせて必要値を読む。候補のPUCT評価順をaction昇順に固定する。unionにはあるが当worldでは非合法なedge、当worldで初めて合法になったmissing edgeを区別する。

**C. node-local action→index表**  
48 byte程度のindex表でlookupする。常設領域増加・insert更新費・全node RSSを測る。速度だけでなく疎なnodeが大量にある場合のcache効率も比較する。

初回はAまたはBから始める。どれか一つを採用し、複数表現を恒久的に保持しない。

### 10.3 厳守事項

- policy_sumの加算順、PUCT式、型、FPU、forced-playout閾値、tie-breakを維持。
- overflowを全候補についてpreflightしてからmutationする契約を維持。
- `edges.reserve/insert`の前に得たpointer/indexは、insertによる再配置・shift後に再利用しない。
- selectionのread-only段階で候補を集める場合、mutation後には選択actionから安全にedgeを引き直す。
- observable nodeのbase policyを「現在あるlegal edges分だけ」に削らない。後発worldで初めて現れるactionのpriorも必要。
- weighted VL sumは最初の実装で変更しない。

native portableで改善しない場合、native-CPU専用版の改善をportableの採用理由にしない。dense vs sparse、合法数1/少数/48、missing edge挿入時、root高占有のfixtureを用意する。

---

## 11. 5B-R：provenance廃止の前にGame scratchを再利用

### 根拠

`clone_light()`はaction historyを省くが、Board内のpurchased/acquired vectorsをcopyする。native traversalはticketごとに新しいGameを作る。[S13/S14]

旧5Bの「provenanceを持たない新Game」を最初の選択肢にしない。先に **worker専有のGameへrootの現在状態をcopy-assignmentし、vector capacityを再利用する** 方式を試す。

### 設計

- workerごとに一つ、synchronous/caller pathではsearch contextに一つのscratch Gameを持つ。
- 同一workerで次ticketを開始する際、scalar、deck、vector内容、mode、cacheをrootから完全reset。
- `Game(seed)`による初期shuffleを毎回行わない。
- history/board_historyはnative searchの契約どおり空。公開`clone_light()`の意味は変えない。
- determinizationはreset後に現行と同じseed・同じRNG・同じshuffleを行う。採番順や乱数消費量を変えない。
- provenanceは保持し、appendも維持。`clear()`しただけで購入情報を省く案とは異なる。
- exact hashのvalid/invalid状態もコピーする。shared rootをconst経由で新たにcache更新しない。
- evaluator requestはowning featuresのまま。requestがscratch Gameのメモリを指さないことを確認。
- cancel/例外後、次のsearchでも必ずroot resetから始まる。

### 検証

各ticketのroot copy、determinized world、selected actions、leaf features、leaf world hashを旧経路と照合する。全履歴vectorの内容も比較する。cold startとwarm reuseを分け、allocation回数と保持capacityの最大値を記録する。

**使われるallocationが減らない形で、cloneした後にvectorを空にする実装は禁止。** clone自体の確保が既に終わっており、狙いを達成しない。

provenanceそのものを廃止するSearchGame型は、この再利用でもclone費用が依然大きく、外部callback/snapshot/proof契約から分離できた場合だけ別承認とする。

---

## 12. 4B-1：legacy record統合

対象は`MCTS::nodes_ / node_aux_ / access_count_`。[S11]

```cpp
struct LegacyTreeRecord {
    MCTSNode node;       // 保持pointer/referenceの意味を維持
    LegacyNodeAux aux;
    uint64_t last_access;
};
```

- 一つのunordered_map内のmemberとしてnodeを配置し、既存mutable APIを維持。
- 現在どのAPIがLRU touchするかをそのまま保つ。全lookupへ新たにtouchを追加しない。
- backpropのVL除去とstats更新が同一hashを二度検索する箇所は、同じ存在確認で処理できるか別小チケットにする。
- prune threshold、counter wrap/reset、outstanding legacy batchとの互換性を維持。
- `get_node_snapshot`等の非touch APIを勝手にtouchさせない。
- effectを主張するのはlegacy実workloadのみ。root-parallelへの効果は実行経路を確認して個別測定。

dense node廃止とflat node arenaはこのチケットに含めない。

---

## 13. 4C：並列共有状態は段階的に削減する

### 13.1 最初の診断

Phase 0ではnode lock waitがshard lock waitより大きいinstrumented sampleがある。しかしinstrumentation自体がscheduleを変えるため、数値を本番時間の内訳とは扱わない。[S08]

root、深さ1、深いnodeを分け、lock取得数、待ち、hold time、reservation occupancy、queue待機を測る。単にshard数を64→256へ増やしてroot node lock競合が解決するとは仮定しない。

### 13.2 4C-1：metrics countersとcorrectness countersを分離

`SearchLedger`の診断集計と、quiescence/overflow/lifetimeを保証するcounterを一覧化する。

- metrics-onlyをworker/role/shard単位へ分散し、quiescence後にreduceする案を先に検討。
- ticketの選択をworker、commit/abortをcoordinatorが行うことがある。同じ「worker用」counterに両threadが書くならplain integerにしない。
- TLSに置くだけでは、移動したRAII reservationのdestructorの書込先・lifetimeは解決しない。
- active中のsnapshot APIがあるなら、集約中のdata raceと一貫性を定義する。
- alignmentは異なるcounterのfalse sharing対策であって、同じglobal atomicへのtrue sharingを消すものではない。
- `validate_quiescent_fast()`が旧generationでmapから外れたlive handleも検出する意味を維持。
- correctness counterのbatch化、global reservation IDの変更は今回は対象外。

### 13.3 4C-2：reservation storage

候補は、現行hash set、inline＋spill、session-owned token poolなど。root高占有とdeep node少数を分けて比較する。

選定条件:

- tokenの一意性、move-only、二重commit/abort拒否、stale generation拒否を維持。
- inline上限を超えても黙ってdropしない。
- rootで数十件をlinear scanする費用を測る。
- 全nodeに大きなinline領域を置くRSS増を測る。
- poolから取り出したrecordの再利用はgeneration付きでABAを防ぐ。
- poolの所有者は残存handleより長生きし、cross-thread deallocationを正しく処理。
- global token IDの意味は監査してから変更。省atomicのために勝手にnode-localへ置換しない。

### 13.4 4C-3：lock取得回数の削減

既存traversalの`state_view()`と、後続`select_and_reserve_bits()`で別々にnode lockを取得する箇所を確認する。内部専用の`inspect_or_select`等で、state確認と選択を同じcritical sectionへまとめる案を検討する。[S14]

- request feature生成やNN callbackをnode lock中へ移さない。
- Unexpanded/Evaluating/Expanded/Terminalの状態機械を保つ。
- owner/waiterのfeature一致検査を削って速くしない。
- `ReservedPath::commit`の全path prevalidationを無断で省略しない。部分backprop禁止の契約が変わる。
- lock-free化やmemory_order緩和は別テーマとする。

### 13.5 queue / persistent workersの保留条件

4A、5B-R、4C後もqueue自体またはthread生成が主費用である場合だけ旧4Dへ進む。

最初は同じmutex/CVを使うbounded ring / bulk push-popを比較する。close・drain・blocked wakeの意味を維持する。1T pathは既にqueueを使わないため、1Tの改善を理由にworker poolを書かない。

Python callbackは既存の非並行契約を維持する。NN待ちが支配的なら、CPU queueの全置換より、実NN batchの測定・複数対局の評価集約など別層の課題として扱う。後者はこのrepoの責務を確認して別計画へ分離する。

---

## 14. 5D：V3 payment codecの静的composition DP

### 14.1 旧2Bの棄却案とは別物

旧棄却案は、ゲーム局面ごとに多数のpayment候補をtableから取り出し、所持gemとdiscountでfilterするものだった。

新案の対象は`ActionEncoderV3::encode_payment_for_card / decode_payment_for_card`。ここでは固定されたprinted costと小さなsumに対して、`count_compositions()`を何度も再帰計算している。[S15]

**合法手集合を変えず、既に決まっているV3 action IDのrank/unrankだけを安くする。**

### 14.2 table

```text
ways[card][position][sum]
ways[c][5][0] = 1
ways[c][5][s > 0] = 0
ways[c][p][s] = Σ ways[c][p+1][s-v]
              v = 0..min(printed_cost[c][p], s)
```

90 card × 6 position × 6 sum × uint16で6,480 bytes。現行sum範囲は0〜5。実装時には最大値と型上限をconstexpr assertionで確認する。

- encodeのsum-prefixと辞書順rankを現行どおり計算し、再帰呼出しをtable lookupへ置換。
- decodeは同じDPを使うか、2,035個の有効patternのpacked direct tableを単独比較する。
- graded lex順と、full-action generatorの列挙順を混同しない。
- invalid card/pattern、gold_as>cost、sum>MAX_GOLDの返り値を維持。
- 公開schema fingerprint、offset、V3 SIZE=3133を変更しない。
- 巨大な90×8^5 direct encode表は最初から作らない。

### 14.3 このレビューでの限定検証

付録Bの独立プローブでは、公開と同一blobのV3 headerを参照し、各成分0..5の全組合せ×90 card、計699,840入力で新DPのrankと旧encoderのrankが一致した。有効2,035 patternの旧decode→新rankも一致した。

これはDP設計の意味論確認であり、ローカル3C環境での速度・API全体の正しさを保証しない。全uint8境界、全action ID、Python binding、maskとの回帰は実装時に追加する。

### 14.4 採否

V3 codec microと、実際のV3 mask/学習runnerを測る。呼ばれていないなら追加しない。native48やexact-reveal NPSへの改善として報告しない。

---

## 15. 3E：visible-onlyのchild代表化を安くする

公開の`representative_actions()`は、候補手を一度適用してchild keyで同一化し、探索時に代表手をもう一度適用する。[S16]

最初の限定案はTAKE_DIFFERENT/TAKE_SAMEだけ。親が同じでnet token deltaが同じなら、通常ルールでは次のgem/bankとその後の標準手番処理が同じになる。この性質をreference childで証明できる範囲に限定して利用する。

```text
delta[color] = take[color] - return[color]  (色0..4)
delta[GOLD]  = -return[GOLD]
```

- 既存generatorが出した合法候補だけをgroup化する。新しい手を作らない。
- group代表は現行のActionOrderKey最小と同じにする。
- 購入・予約・貴族・PASSを同じdeltaだからと混ぜない。
- editorのoverflow/非正規入力、異なるaction semanticsはreferenceへfallback。
- cache用64-bit hashだけの一致でgroup化しない。delta列を完全比較する。
- 初回はその場のtake groupだけを減らし、最終child-key代表化をreferenceとして残す。
- candidate群・代表code順・後続snapshotを全照合する。

「最終的に同じ代表手集合をもっと安く作る」S0案であり、強そうな手だけを残すpruningではない。3B/3Cで既にchild代表化を改善していれば重複実装しない。

---

## 16. 5E：full-actionのrank選択

`apply_random_action(random_value)`は、count後に`random_value % count`番目まで再列挙している。[S13]

全候補を必要とせず一手だけ欲しい場合、branch件数で先行branchをskipし、選択branchのみunrankする方法を検討する。

第一段階は既存return count/tableを利用し、返却subtreeのprefix列挙だけをskipする。新しい一般purpose payment DPを同時に入れない。旧2Bでruntime DPが棄却された事実を踏まえる。

必須契約:

- `% count`を維持。乱数分布やRNGの消費を変えない。
- base/finalの二段階`MAX_MOVES` capと、切り捨てられるprefixを維持。
- 全indexについて旧`legal_action_codes()[i]`と同じcode。
- simple/full、token no-op、forced PASS、excess>3 editor fallbackを保持。
- range外indexと空候補の返り値は公開APIごとに現行と同じ。

1手選択に十分小さいscratchで済むことを測定し、局面全体への大きなcache追加は避ける。countが主費用なのか、prefix materializationが主費用なのかを分ける。

---

## 17. 5A / 5C-B：小さな追加案の整理

### 17.1 48-index直接適用

decodeは既に大幅高速化済みなので、最初から高い優先度を付けない。

直接適用を作るなら、source slotを持つinternal ResolvedAction等を通常rule primitiveへ渡し、支払い・貴族・終局処理を複製しない。局面が変わった後にdescriptorを使い回さない。公開Action wire formatは維持する。

全48 slotを含むrandom differential、hidden reserve、重複card editor fallback、forced PASSはpolicy外という契約を試す。

### 17.2 immutable feature table

`StateEncoder`はcardの固定points/cost/bonus/levelを毎回floatへ変換・正規化する。90×8 floatの定数tableと、空slot/hidden-tier専用tableを比較する。[S17]

- observer相手のhidden reserveをfull card vectorで埋めない。
- 全特徴量でbitwise oracleを取り、定数folding・除算→乗算・canonical swapによる差を確認。
- StateEncoder schema/versionを変えない。
- `encode_public_card_statistics`のpool sortや浮動小数加算順変更は別チケット。
- compilerが既に十分最適化している場合は棄却。

### 17.3 Python buffer境界

既存list[int]やAction APIは残す。buffer書込み/NumPyのadditive APIは、呼出し側が実際に使用する場合だけ追加する。

shape/dtype/contiguity/writable/容量を検証し、失敗時の部分書込み規則を明示する。C++ stack scratchや次の呼出しで再利用されるbufferを、owning ndarrayとして偽装しない。保持した配列が次のsearchで変わらないことをテストする。

---

## 18. Phase 6：build profileを正しく評価する

### 18.1 まず実flagsを監査

CMakeListsだけで判定せず、`compile_commands.json`、verbose build、link commandから以下を記録する。

- Python extensionとnative executableそれぞれの-O、NDEBUG、LTO、CPU target。
- pybind11が暗黙に追加しているflags。
- sanitizer / instrumentation / verifyの有無。
- source・compiler・linker・CMake・pybind11版。

LTOが既に有効なら「導入で高速化」と記録しない。native benchmarkだけLTOなしなら、比較表を分ける。[T02]

### 18.2 native profile

portableを既定として維持し、Linux x86_64 local-onlyのnative targetを明示する。wheel guard、cross build、Apple Silicon既存profileを壊さない。CPU依存命令を配布物へ混入させない。

### 18.3 PGO

同じsourceをprofile-generateで学習し、profile-useで本番binaryを作る。学習fixtureと採否用holdout fixtureを分ける。失敗/stop/hidden情報経路も学習対象へ入れる。

- GCC/Clangのprofileを混ぜない。
- profileのsource/flags identityを保存し、stale/mismatchを無視しない。
- multi-thread収集時のcounter整合性を公式toolchain仕様で確認。
- 不一致warningを消して強行しない。
- generate binaryの実行時間を高速化後として報告しない。

### 18.4 数値規則

`-Ofast`、`-ffast-math`、`-ffinite-math-only`はこの性能計画の既定対象外。現行の`isfinite`/NaN拒否、PUCT、確定traceを壊す可能性がある。[T03]

portable、native、LTO、PGOの効果を別表にし、code最適化の効果と混ぜない。

---

## 19. 採否・測定規約 改訂

### 19.1 三つのbuildを混同しない

| build | 用途 |
|---|---|
| reference / correctness | full snapshot、旧演算、強いoracle、sanitizer |
| diagnostic | allocation/lock/call count。observer effectを許容して機序を測る |
| deployment-equivalent Release | instrumentation/verifyなし。採否の実時間を測る |

diagnosticだけで速くなっても採用しない。referenceとcandidateを同居させて巨大化した試作binaryと、最終配置binaryも区別する。2A棄却記録にcode-layout影響があるため、最終形でも対照を再確認する。[S04]

### 19.2 paired A/B

既存の固定slot crossover・ABBA runnerを再利用する。安易に別runnerを新設しない。

- 同じsource基準・toolchain・flags・fixture・seed・予算・cache初期状態。
- 事前warmup後、独立crossover block単位でbootstrapする。
- 目安は既存と同等の22 pair / 11 block以上。多重比較で最も良い結果だけ採用しない。
- primaryとguardを先に宣言し、候補を決めた後に独立holdoutで再確認。
- `speedup = time_A/time_B`。同じ処理量のrateなら`rate_B/rate_A`。rateと時間の向きを混ぜない。
- median(pair ratios)とratio(medians)は一致するとは限らない。どちらを主値にしたか記載する。
- 実行順・build slot・thermal/CPU backgroundの条件を記録。
- boilerplate/harness時間が支配的な極小処理はまとめて反復し、最適化で消されないようchecksumを消費。

### 19.3 性能gateは実装複雑性に比例させる

以下は**採用閾値の目安であり予測値ではない**。

- 数十行の単純な冗長処理除去：primaryで再現する約2〜3%以上を基本とする。より小さい改善でも、コード削減・測定の強さを根拠に例外を文書化できる。
- 新しいstate表現、複雑なrollback、token pool：primary end-to-endで約5%以上、または十分大きなRSS削減を要求する。
- 他の主要workloadの退行：2%をguard目安とし、単発medianの揺れだけで断定せずCIと独立再測定で判定。
- microだけ改善、end-to-end中立：通常は棄却。依存となる設計基盤として残すなら別途明示承認。
- 高速化倍率の単純乗算をしない。各commitの単独効果と累積HEADの効果を別測定。

参考に、全時間に占める対象処理の割合を`p`、その処理の残存時間比を`q`とすると、理想化した全体倍率は`1/((1-p)+p*q)`。局所処理が10倍速くても、割合が小さければ大改造の根拠にならない。

### 19.4 S0のsemantic gate

同じ固定workについて、以下を比較する。

```text
result/status/unknown_reason/winner
ordered action codes and reveal IDs
visited nodes / terminal nodes / legal move count
memo hits / persistent hits / retained entries（同じcache規則の場合）
winning action / principal line
proof/frontierの意味的同値性
parent/child state、hash oracle、sidecar oracle
```

内部のallocation/copy/score-call/lookup回数は改善対象なので同一性gateへ入れない。公開logical countersと診断implementation countersをschema上も区別する。

TT entry layoutを変えたためiteration順が変わり、eviction対象まで変化する場合は、単なる構造体圧縮でも探索内容へ影響し得る。その変更はS0とみなさず、まず旧eviction対象を保存する。

### 19.5 非同期MCTSのgate

throughput modeでは同じseedでもschedulerが変わる。tree digest/root訪問分布の完全一致を要求しない代わりに、以下を必須にする。

- `issued = completed + cancelled + failed`等、現行ledgerの不変条件。
- virtual lossとlive reservationの完全回収。
- stale/duplicate publish、owner failure、waiter attach、capacity/cancelでの挙動。
- deterministic epoch oracleで同じ論理順のtrace/float結果一致。
- **completed sims/s、unique evaluated leaves/s、path steps/s、owner/waiter比、停止理由**を同時報告。
- 予算未完了runの分子にrequested simulationsを使わない。
- 温存tree/fresh treeを分け、50,000 node等のcapacity到達を「完了run」と混ぜない。
- fake evaluatorだけで棋力改善を主張しない。NN利用可能なら固定時間のroot分布、証明到達率、paired self-play等を別gateで実施。

### 19.6 テストを段階化して作業費用を抑える

1. 小さな単体oracleと該当subsystemのdifferential。
2. 短いA/B smoke。明確に遅ければここで棄却。
3. 正式paired A/Bとholdout。
4. 採用候補だけfull native/Python、ASan+UBSan。並列関連はTSanとrace/failure injection。
5. 累積変更の統合回帰。

基準側にもあるfailure、環境上実行不可、候補固有failureを別記する。LSanやperf等が使えなければ理由を記録し、テストや閾値を削って成功扱いにしない。実NNがrepo外にある場合、そのgateは未実施として残す。

---

## 20. 最小のbenchmark matrix

全直積ではなく、変更の経路に合わせる。

| 変更 | primary | 必須guard |
|---|---|---|
| 3D-P1/P2 | exact reveal deep + shallow + warm session | visible-only、proof on/off、editor fallback |
| 3D-1/2/3 | 同じ探索量のsolver時間・allocation/node | 全ActionType、めくれ訪問1/多数、cancel/throw、full snapshot |
| 4A | ConcurrentTree selection + 実利用MCTS backend | 1T/4T/8T、exact/observable、deterministic epoch、missing edges |
| 5B-R | clone/reset＋native MCTS | deterministic world digest、履歴多寡、callback保持、cold/warm |
| 4B-1 | legacy MCTS、prune込み長期session | mutable node API、retained tree、snapshot |
| 4C | shared throughputと整合性 | latency 0/250µs程度、batch1/16/64、TSan、root高占有 |
| 5D | V3 encode/decode/mask、V3利用runner | 全pattern、全V3 ID、Python binding、48/V2不変 |
| 3E/5E | visible representative / full-action self-play | 全index・全代表手、cap、mode、token no-op |
| 6 | 主workloadの実配置binary | portable、wheel、数値oracle、PGO holdout |

run時間だけでなく、engine本体・Python境界・proof出力・session準備のどこを含むかを明記する。異なるworkloadのNPSを同じ尺度として比較しない。

---

## 21. 実装しないこと・停止条件

- 完了済み0〜3Cの全面書き直し。
- 棄却済みobservable cache、packed差分、payment filter tableの無根拠な再導入。
- 3Cを見ないまま新しいTTをもう一つ作ること。
- full keyに64-bit hashが含まれるだけなのに「衝突が絶対にない」とすること。slot fingerprintとkey equalityを混同しない。
- shared throughputへbitwise同一結果を要求し、偶然一致するrunだけ採用すること。
- all-path prevalidation、finite check、fallback、overflow checkを消して性能を得ること。
- public `MCTSNode*`を一時snapshotへのpointerへ変更すること。
- ordered deckのswap-remove、支払いの簡略化、守備側応手の間引きをS0として行うこと。

実測が中立ならREJECT_AND_REVERT、必要な観測が不足するならNEEDS_MORE_DATA。名称だけ「高速化」にして採用しない。revertするのは自分が作成した当該チケットの差分だけとする。

---

## 22. Codexの報告書式

```text
Ticket:
Classification: S0 / S1 / S2
Baseline commit + working-tree digest:
Candidate commit + source digest:
Prior phases preserved:
Primary workload and success criterion:
Reference implementation:
Changed symbols:
Assumptions checked against local 3B/3C:
Correctness / sanitizer / failure-injection results:
Performance: A, B, speedup, block CI, holdout
Memory: allocations, allocated bytes, retained capacity, peak RSS
Mechanism: which redundant operation actually disappeared
Unmeasured items / environment limitations:
Decision: ACCEPT / REJECT_AND_REVERT / NEEDS_MORE_DATA / SKIP_ALREADY_DONE
Next single ticket:
```

表には単位とsource artifact pathを付ける。短い集計と再現コマンドはGitへ、巨大rawは既存方針に従い圧縮・内容hashで保存する。`.so/.o/build/venv`、モデル、秘密情報はcommitしない。pushしない。

---

## 付録A. 参照資料

### リポジトリ資料

参照base（以下各pathはこのcommitに固定）:

```text
https://github.com/kuboyoo/csplendor/tree/0c5eba654ab4536c70947e725872cf5790db5e92
```

- **[S01]** `doc/performance_experiments/baseline_20260902.md` — Phase 0の条件、gprof/perf制約、計測基盤。
- **[S02]** `doc/performance_experiments/phase1a_exact_hash_20260902.md` — exact hash採用結果とRuleMutator。
- **[S03]** `doc/performance_experiments/phase1b_observable_hash_20260902.md` — observable cache棄却。
- **[S04]** `doc/performance_experiments/phase2a_packed_resources_rejected_20260902.md` — packed値差分の棄却・code-layout影響。
- **[S05]** `doc/performance_experiments/phase2b_single_pass_codes_20260902.md` — codes一回生成。
- **[S06]** `doc/performance_experiments/phase2b_payment_pattern_table_rejected_20260902.md` — 候補filter表の棄却。
- **[S07]** `doc/performance_experiments/phase3a_solver_containers_20260902.md` — 有界path・無制限path、allocation、採否。
- **[S08]** `doc/performance_experiments/instrumentation_20260902.json` — reservation占有、lock、allocation等。Phase 0時点。
- **[S09]** `src/mcts_root_parallel.h` — local modeをDeterministicEpochへ設定するworker経路。
- **[S10]** `src/mcts_concurrent_tree.h` — access metadata、PUCT、token、path commit。
- **[S11]** `src/mcts_tree.h` — legacy三重map、mutable node API、prune。
- **[S12]** `src/reveal_verified_solver.cpp` — candidate scoring、concrete refill、deck erase、snapshot restore。
- **[S13]** `src/game.h`, `src/player.h`, `src/undo_record.h` — clone、vectors、random index選択、旧delta候補。
- **[S14]** `src/mcts_parallel_searcher.h`, `src/mcts_parallel_session.h` — ticket traversalとGame lifetime。
- **[S15]** `src/action_encoder_v3.h` — composition rank/unrank。blob `89dbd0d2f36f13b6036ded85987a8c1e917209c5`。
- **[S16]** `src/visible_only_solver.cpp` — representative_actionsのapply/key/restore。
- **[S17]** `src/state_encoder.h` — feature生成・observer契約。

未閲覧の3B/3C報告をこの一覧へ架空のfile名で追加してはならない。R0で実在するpathとcommitを追記する。

### 外部一次資料（2026-09-05参照）

- **[T01]** C++標準草案、unordered associative containersのiterator/reference保証。  
  `https://eel.is/c++draft/unord.req`
- **[T02]** pybind11公式Build systems / CMake helpers。LTOの既定挙動とNO_EXTRAS。  
  `https://pybind11.readthedocs.io/en/stable/compiling.html`  
  `https://pybind11.readthedocs.io/en/stable/cmake/`
- **[T03]** GCC公式Optimize Options。fast-math / finite-math-only / profile-use等。  
  `https://gcc.gnu.org/onlinedocs/gcc-15.2.0/gcc/Optimize-Options.html`

---

## 付録B. このレビューで実行した独立プローブ

同梱の`probes/review_semantic_probes.cpp`は、エンジンへのpatchではなく、計画上の小さな性質を確認するstandalone testである。

確認環境:

```text
c++ (Debian 14.2.0-19) 14.2.0
-O2 -std=c++17
参照header: 元アップロードに含まれるsrc/action_encoder_v3.h
同headerのGit blob SHA: 89dbd0d2f36f13b6036ded85987a8c1e917209c5
公開REVIEW_REFから取得した同fileのblobと一致
```

出力:

```json
{
  "kind": "semantic_only_not_performance",
  "payment_rank_cases": 699840,
  "legal_payment_patterns": 2035,
  "bit_rank_cases": 480000,
  "ways_table_bytes": 6480,
  "ordered_weighted_sum": 1.8,
  "multiply_total_once": 1.7999999999999998,
  "floating_reduction_differs": true,
  "semantic_probe_result": "PASS"
}
```

再実行（リポジトリrootから、fileの配置に合わせてpathを変更）:

```bash
c++ -O2 -std=c++17 -Isrc /path/to/probes/review_semantic_probes.cpp \
  -o /tmp/csplendor-review-semantic-probes
/tmp/csplendor-review-semantic-probes
```

対象はV3 static codecの限られた入力域、bit-rank式、浮動小数加算の反例のみ。thread safety、solver証明、rollback、エンジン全回帰、性能は検証していない。このPASSをPhase 3C後のproduction gateの代用にしない。
